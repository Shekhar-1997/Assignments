import java.util.ArrayList;
import java.util.List;

import com.fruit.Fruit;
import com.fruit.Mango;

public class Basket {
	public static List<Fruit> fruitList = new ArrayList<>();
	
	public  static void addFruit(Fruit fruit) throws InterruptedException{
//		System.out.printf("\n Inside addFruit for int %s",i);
		
		
        if (fruitList.size()<5) {
            fruitList.add(fruit);
        } else {
            System.out.println("Cannot add more than 5 fruits to list");
        }
		
	}
	
	public static Fruit removeFruit() throws InterruptedException{
//		System.out.printf("\n Inside removeFruit for int ");
		
		
		Fruit i = fruitList.remove(0);
		
		
		return i;
	}
	
	public boolean isEmpty() {
		return fruitList.isEmpty();
	}
	public static int count=0;
	public static void main(String[] args) {
		ArrayList<Mango> m=new ArrayList();
	Mango m1=new Mango("Mango","light yellow",70);
	Mango m2=new Mango("Mango","medium yellow",75);
	Mango m3=new Mango("Mango","dark yellow",80);
	Mango m4=new Mango("Apple","Kashmir apple",120);
	Mango m5=new Mango("Apple","Karnataka apple",110);
	Mango m6=new Mango("Apple","Karnataka apple",110);

	//we are just using Mango and placing there Apple because
	//we can add in a single array list
		if(count<=4) {
			count++;
			m.add(m5);
		}
			if(count<=4) {
				count++;
				m.add(m4);
			}
		if(count<=4) {
			count++;
			m.add(m3);
			}
			if(count<=4) {
				count++;
				m.add(m3);
				}
		if(count<=4) {
			count++;
				m.add(m3);
				count++;
				}
			if(count<4) {
				count++;
				m.add(m2);
			}
		if(count<4) {
			count++;
			m.add(m5);
		}
		if(count<4) {
			count++;
			m.add(m6);
		}
		else {
			System.out.println("we cannot add more than 5");
		}
		System.out.println("max only "+count+"starts from 0 so its 4");

	for(Mango l:m) {
		System.out.println(l);
	}
	}
	
}