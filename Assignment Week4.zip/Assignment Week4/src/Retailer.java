import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import com.fruit.*;
public class Retailer extends Basket {
	private String retailerName;
	private int age;
	Basket fruitBasket;

	public Retailer(String name, int i) {
		this.retailerName = name;
		this.age = i;
	}

	public void buy() throws InterruptedException, IOException {
				

			Fruit fruit = Basket.removeFruit();
			System.out.printf("\nPURCHASED fruit by "+this.retailerName+" of age "+this.age+"\n");

            ObjectOutputStream os = null;
            
            try {
                os = new ObjectOutputStream(new FileOutputStream("output1.txt"));
                os.writeObject(fruit);
                System.out.println("Fruit Added");
            } catch (FileNotFoundException e) {
            } catch (IOException e) {
            } finally {
                os.close();
            
			
		}
	}


}