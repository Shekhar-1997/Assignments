package com.fruit;
public interface Fruit {	
	public static final int count = 0;

	void cut();
	
	void makeJuice();

    

}
