import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.opencsv.CSVReader;
import com.opencsv.CSVWriter;

import People.Farmer;

public class Main {
	 static List <Farmer>farmersList = new ArrayList<Farmer>();
	public static void main(String[] args) {
		readFromFile();
		
	}


	public static void writeIntoFile() 
	{
		String filePath = "C:\\Users\\Admin\\eclipse-workspace\\WeekFiveAssignment\\farmers.txt";
		File file = new File(filePath);
		try {
			FileWriter outputfile = new FileWriter(file);
			CSVWriter writer = new CSVWriter(outputfile);
			for(int i=0;i<10;i++) {
				Farmer temp =  Main.farmersList.get(i);
				String[] temp1 = {temp.getName(),temp.getAge(),temp.getState(),temp.getPhone()};
				writer.writeNext(temp1);
			}
			writer.close();
		}
		catch (IOException e) 
		{
			e.printStackTrace();
		}

	}
	
	public static void readFromFile() 
	{
		 try {
			  
		        String file = "C:\\Users\\Admin\\eclipse-workspace\\WeekFiveAssignment\\farmers.txt";
		        FileReader filereader = new FileReader(file);
		        CSVReader csvReader = new CSVReader(filereader);
		        String[] nextRec;
		        while ((nextRec = csvReader.readNext()) != null) {
		            for (String cell : nextRec) {
		                System.out.print(cell + "\t");
		            }
		            System.out.println();
		            checkPhoneNumber(nextRec[3]);
		        }
		    }
		    catch (Exception ex) {
		        ex.printStackTrace();
		    }
	}
	
	static void checkPhoneNumber(String sourceText1) 
	{
		//String sourceText1 = "7864556464 is my number 982424612 also and also 453553500";
		Pattern pattern = Pattern.compile("^\\d{10}$");
		Matcher matcher = pattern.matcher(sourceText1);
		//System.out.println("\n Pattern " + "\b[7-9](\\d){9}\b");
		if(matcher.find()) {
			System.out.println("number is valid ");
		}
		else
			System.out.println("number is not valid ");
	}
	
}


